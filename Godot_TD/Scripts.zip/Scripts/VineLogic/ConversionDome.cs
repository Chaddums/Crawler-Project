using System.Collections.Generic;
using Godot;

namespace JunkyardTD
{
    /// <summary>
    /// Visual dome around the harvester. Procedural ground ring with concentric
    /// circles, rotating geometric pattern, and rising energy particles.
    /// All geometry conforms to terrain heightmap. Radius tied to harvester HP.
    /// </summary>
    public partial class ConversionDome : Node3D
    {
        // Dome state
        public float MaxRadius { get; private set; } = 10f;
        public float CurrentRadius { get; private set; } = 10f;
        public float BaseFloorRadius { get; private set; } = 10f;

        // Visual components — rebuilt each frame to conform to terrain
        private MeshInstance3D _ringsMesh;       // All concentric rings + hex pattern
        private MeshInstance3D _glowDisc;        // Faint filled disc
        private MeshInstance3D _shieldSphere;
        private StandardMaterial3D _ringsMat;
        private StandardMaterial3D _dimRingsMat;
        private StandardMaterial3D _discMat;
        private StandardMaterial3D _shieldMat;
        private float _shieldFlashTimer;

        // Rising energy particles
        private readonly List<EnergyParticle> _particles = new();
        private float _particleSpawnTimer;

        // Animation
        private float _time;
        private VineGrid _grid;

        // Last stand state
        public bool IsLastStand { get; private set; }
        private int _lastStandHits;
        public const int LAST_STAND_MAX_HITS = 10;

        // Colors
        private static readonly Color AccentCyan = new(0.0f, 0.85f, 0.95f);
        private static readonly Color AccentDim = new(0.0f, 0.5f, 0.6f);

        private struct EnergyParticle
        {
            public MeshInstance3D Mesh;
            public float Life;     // 0→1, dies at 1
            public float MaxLife;
            public Vector3 BasePos;
            public float Speed;
            public float RotSpeed;
        }

        public override void _Ready()
        {
            _grid = ServiceLocator.TryGet<VineGrid>(out var g) ? g : null;

            BuildMaterials();
            BuildRingsMesh();
            BuildGlowDisc();
            BuildShieldSphere();

            GameEvents.OnHarvesterDamaged += OnHarvesterDamaged;
        }

        // ── Materials ──

        private void BuildMaterials()
        {
            _ringsMat = new StandardMaterial3D();
            _ringsMat.ShadingMode = BaseMaterial3D.ShadingModeEnum.Unshaded;
            _ringsMat.Transparency = BaseMaterial3D.TransparencyEnum.Alpha;
            _ringsMat.AlbedoColor = new Color(AccentCyan.R, AccentCyan.G, AccentCyan.B, 0.8f);
            _ringsMat.EmissionEnabled = true;
            _ringsMat.Emission = AccentCyan;
            _ringsMat.EmissionEnergyMultiplier = 1.0f;

            _dimRingsMat = new StandardMaterial3D();
            _dimRingsMat.ShadingMode = BaseMaterial3D.ShadingModeEnum.Unshaded;
            _dimRingsMat.Transparency = BaseMaterial3D.TransparencyEnum.Alpha;
            _dimRingsMat.AlbedoColor = new Color(AccentDim.R, AccentDim.G, AccentDim.B, 0.5f);
            _dimRingsMat.EmissionEnabled = true;
            _dimRingsMat.Emission = AccentDim;
            _dimRingsMat.EmissionEnergyMultiplier = 0.5f;

            _discMat = new StandardMaterial3D();
            _discMat.ShadingMode = BaseMaterial3D.ShadingModeEnum.Unshaded;
            _discMat.Transparency = BaseMaterial3D.TransparencyEnum.Alpha;
            _discMat.AlbedoColor = new Color(0f, 0.6f, 0.8f, 0.06f);
            _discMat.EmissionEnabled = true;
            _discMat.Emission = AccentCyan;
            _discMat.EmissionEnergyMultiplier = 0.1f;
        }

        // ── Visual construction ──

        private void BuildRingsMesh()
        {
            _ringsMesh = new MeshInstance3D();
            _ringsMesh.MaterialOverride = _ringsMat;
            AddChild(_ringsMesh);
            RebuildRings();
        }

        private void BuildGlowDisc()
        {
            _glowDisc = new MeshInstance3D();
            _glowDisc.MaterialOverride = _discMat;
            AddChild(_glowDisc);
            RebuildDisc();
        }

        /// <summary>
        /// Sample terrain height at a world XZ position relative to dome center.
        /// </summary>
        private float SampleHeight(float worldX, float worldZ)
        {
            if (_grid == null) return 0f;
            return _grid.GetWorldHeight(worldX, worldZ);
        }

        /// <summary>
        /// Get a point on a circle at the dome's world position, conforming to terrain.
        /// </summary>
        private Vector3 RingPoint(float radius, float angle, float yOffset = 0.1f)
        {
            float wx = GlobalPosition.X + Mathf.Cos(angle) * radius;
            float wz = GlobalPosition.Z + Mathf.Sin(angle) * radius;
            float wy = SampleHeight(wx, wz) + yOffset;
            // Return in local space (relative to dome position)
            return new Vector3(Mathf.Cos(angle) * radius, wy - GlobalPosition.Y, Mathf.Sin(angle) * radius);
        }

        private void RebuildRings()
        {
            var im = new ImmediateMesh();
            float r = CurrentRadius;
            float pulse = 1f + Mathf.Sin(_time * 2f) * 0.03f;
            float geoRot = -_time * 25f * Mathf.Pi / 180f; // Geometric pattern rotation

            im.SurfaceBegin(Mesh.PrimitiveType.Lines);

            // Outer ring — 64 segments, bright
            DrawCircle(im, r * pulse, 64, 0.1f);

            // Outer ring duplicate slightly offset for thickness
            DrawCircle(im, r * pulse * 0.98f, 64, 0.12f);

            im.SurfaceEnd();

            // Second surface for dimmer inner rings
            im.SurfaceBegin(Mesh.PrimitiveType.Lines, _dimRingsMat);

            // Mid ring
            float midAlpha = 0.4f + Mathf.Sin(_time * 3f) * 0.15f;
            DrawCircle(im, r * 0.82f, 48, 0.11f);

            // Inner ring
            DrawCircle(im, r * 0.6f, 48, 0.12f);

            // Rotating hexagon with inner triangle
            DrawHexPattern(im, r * 0.72f, geoRot, 0.13f);

            // Radial tick marks on outer ring (12 evenly spaced)
            for (int i = 0; i < 12; i++)
            {
                float angle = Mathf.Tau * i / 12f + _time * 0.3f;
                var inner = RingPoint(r * 0.9f, angle, 0.11f);
                var outer = RingPoint(r * 1.02f * pulse, angle, 0.11f);
                im.SurfaceAddVertex(inner);
                im.SurfaceAddVertex(outer);
            }

            im.SurfaceEnd();

            _ringsMesh.Mesh = im;
        }

        private void DrawCircle(ImmediateMesh im, float radius, int segments, float yOff)
        {
            for (int i = 0; i < segments; i++)
            {
                float a0 = Mathf.Tau * i / segments;
                float a1 = Mathf.Tau * (i + 1) / segments;
                im.SurfaceAddVertex(RingPoint(radius, a0, yOff));
                im.SurfaceAddVertex(RingPoint(radius, a1, yOff));
            }
        }

        private void DrawHexPattern(ImmediateMesh im, float radius, float rotation, float yOff)
        {
            int sides = 6;
            // Hex outline
            for (int i = 0; i < sides; i++)
            {
                float a0 = Mathf.Tau * i / sides + rotation;
                float a1 = Mathf.Tau * (i + 1) / sides + rotation;
                im.SurfaceAddVertex(RingPoint(radius, a0, yOff));
                im.SurfaceAddVertex(RingPoint(radius, a1, yOff));
            }
            // Inner triangle connecting alternating vertices
            for (int i = 0; i < sides; i += 2)
            {
                float a0 = Mathf.Tau * i / sides + rotation;
                float a1 = Mathf.Tau * ((i + 2) % sides) / sides + rotation;
                im.SurfaceAddVertex(RingPoint(radius * 0.55f, a0, yOff));
                im.SurfaceAddVertex(RingPoint(radius * 0.55f, a1, yOff));
            }
        }

        private void RebuildDisc()
        {
            // Flat disc conforming to terrain — build as triangle fan on XZ
            var st = new SurfaceTool();
            st.Begin(Mesh.PrimitiveType.Triangles);

            int segments = 32;
            float r = CurrentRadius;
            var center = new Vector3(0, SampleHeight(GlobalPosition.X, GlobalPosition.Z) - GlobalPosition.Y + 0.05f, 0);

            for (int i = 0; i < segments; i++)
            {
                float a0 = Mathf.Tau * i / segments;
                float a1 = Mathf.Tau * (i + 1) / segments;
                var p0 = RingPoint(r, a0, 0.05f);
                var p1 = RingPoint(r, a1, 0.05f);

                st.AddVertex(center);
                st.AddVertex(p0);
                st.AddVertex(p1);
            }

            st.GenerateNormals();
            _glowDisc.Mesh = st.Commit();
        }

        private void BuildShieldSphere()
        {
            _shieldSphere = new MeshInstance3D();
            var sphere = new SphereMesh();
            sphere.Radius = 1f;
            sphere.Height = 2f;
            sphere.RadialSegments = 16;
            sphere.Rings = 8;
            _shieldSphere.Mesh = sphere;
            _shieldSphere.Visible = false;

            _shieldMat = new StandardMaterial3D();
            _shieldMat.Transparency = BaseMaterial3D.TransparencyEnum.Alpha;
            _shieldMat.ShadingMode = BaseMaterial3D.ShadingModeEnum.Unshaded;
            _shieldMat.AlbedoColor = new Color(0.3f, 0.8f, 1.0f, 0f);
            _shieldMat.EmissionEnabled = true;
            _shieldMat.Emission = new Color(0.3f, 0.8f, 1.0f);
            _shieldMat.EmissionEnergyMultiplier = 0f;
            _shieldMat.CullMode = BaseMaterial3D.CullModeEnum.Back;
            _shieldSphere.MaterialOverride = _shieldMat;
            _shieldSphere.Position = new Vector3(0, CurrentRadius * 0.3f, 0);
            AddChild(_shieldSphere);
        }

        // ── Rising energy particles ──

        private void SpawnParticle()
        {
            // Spawn at random point on outer ring edge
            float angle = GD.Randf() * Mathf.Tau;
            float wx = GlobalPosition.X + Mathf.Cos(angle) * CurrentRadius;
            float wz = GlobalPosition.Z + Mathf.Sin(angle) * CurrentRadius;
            float wy = SampleHeight(wx, wz);

            var mesh = new MeshInstance3D();
            // Diamond shape — rotated box
            var box = new BoxMesh();
            float size = GD.Randf() * 0.12f + 0.06f;
            box.Size = new Vector3(size, size * 1.5f, size);
            mesh.Mesh = box;
            mesh.RotationDegrees = new Vector3(0, 0, 45); // Diamond orientation

            var mat = new StandardMaterial3D();
            mat.ShadingMode = BaseMaterial3D.ShadingModeEnum.Unshaded;
            mat.Transparency = BaseMaterial3D.TransparencyEnum.Alpha;
            mat.AlbedoColor = new Color(AccentCyan.R, AccentCyan.G, AccentCyan.B, 0.9f);
            mat.EmissionEnabled = true;
            mat.Emission = AccentCyan;
            mat.EmissionEnergyMultiplier = 1.5f;
            mesh.MaterialOverride = mat;

            GetParent().AddChild(mesh);
            mesh.GlobalPosition = new Vector3(wx, wy + 0.2f, wz);

            _particles.Add(new EnergyParticle {
                Mesh = mesh,
                Life = 0f,
                MaxLife = GD.Randf() * 1.5f + 1.0f,
                BasePos = mesh.GlobalPosition,
                Speed = GD.Randf() * 1.5f + 1.0f,
                RotSpeed = GD.Randf() * 180f - 90f,
            });
        }

        private void UpdateParticles(float dt)
        {
            // Spawn rate scales with radius
            _particleSpawnTimer += dt;
            float spawnInterval = 0.15f; // ~7 particles/sec
            while (_particleSpawnTimer >= spawnInterval)
            {
                _particleSpawnTimer -= spawnInterval;
                if (CurrentRadius > 0.5f)
                    SpawnParticle();
            }

            // Update existing particles
            for (int i = _particles.Count - 1; i >= 0; i--)
            {
                var p = _particles[i];
                p.Life += dt / p.MaxLife;

                if (p.Life >= 1f || !GodotObject.IsInstanceValid(p.Mesh))
                {
                    if (GodotObject.IsInstanceValid(p.Mesh))
                        p.Mesh.QueueFree();
                    _particles.RemoveAt(i);
                    continue;
                }

                // Rise upward
                var pos = p.BasePos + new Vector3(0, p.Speed * p.Life * p.MaxLife, 0);
                p.Mesh.GlobalPosition = pos;

                // Spin
                p.Mesh.RotationDegrees += new Vector3(0, p.RotSpeed * dt, 0);

                // Fade out in second half of life
                float alpha = p.Life < 0.5f ? 1f : 1f - (p.Life - 0.5f) * 2f;
                float scale = 1f - p.Life * 0.3f; // Shrink slightly
                p.Mesh.Scale = Vector3.One * Mathf.Max(0.1f, scale);
                if (p.Mesh.MaterialOverride is StandardMaterial3D mat)
                {
                    mat.AlbedoColor = new Color(AccentCyan.R, AccentCyan.G, AccentCyan.B, alpha * 0.8f);
                    mat.EmissionEnergyMultiplier = 1.5f * alpha;
                }

                _particles[i] = p;
            }
        }

        // ── Update loop ──

        public override void _Process(double delta)
        {
            float dt = (float)delta;
            _time += dt;

            // Rebuild rings each frame (conforms to terrain, animates rotation/pulse)
            RebuildRings();

            // Rising energy particles
            UpdateParticles(dt);

            // Shield flash decay
            if (_shieldFlashTimer > 0)
            {
                _shieldFlashTimer -= dt;
                float t = Mathf.Clamp(_shieldFlashTimer / 0.5f, 0f, 1f);
                _shieldMat.AlbedoColor = new Color(0.3f, 0.8f, 1.0f, t * t * 0.25f);
                _shieldMat.EmissionEnergyMultiplier = t * t * 2f;

                if (_shieldFlashTimer <= 0)
                    _shieldSphere.Visible = false;
            }

            // Last stand — rapid flicker on outer ring material
            if (IsLastStand)
            {
                float flicker = Mathf.Sin(_time * 20f) * 0.5f + 0.5f;
                _ringsMat.AlbedoColor = new Color(1f, 0.3f + flicker * 0.4f, 0.2f, 0.7f);
                _ringsMat.Emission = new Color(1f, 0.4f, 0.1f);
            }
        }

        // ── Dome radius control ──

        public void SetFloorRadius(int floor)
        {
            BaseFloorRadius = 8f + (floor - 1) * 3f;
            MaxRadius = BaseFloorRadius;
            SetRadius(MaxRadius);
        }

        public void GrowForWave(int waveNumber, int totalWaves)
        {
            float progress = (float)waveNumber / totalWaves;
            float targetRadius = BaseFloorRadius * (0.6f + progress * 0.4f);
            SetRadius(Mathf.Max(CurrentRadius, targetRadius));
        }

        public void ShrinkForDamage(float hpPercent)
        {
            if (IsLastStand) return;
            float newRadius = MaxRadius * hpPercent;
            if (newRadius <= 0.5f)
            {
                EnterLastStand();
                return;
            }
            SetRadius(newRadius);
        }

        public void RestoreDome()
        {
            IsLastStand = false;
            _lastStandHits = 0;
            SetRadius(BaseFloorRadius * 0.5f);
            _ringsMat.AlbedoColor = new Color(AccentCyan.R, AccentCyan.G, AccentCyan.B, 0.8f);
            _ringsMat.Emission = AccentCyan;
            GD.Print("[ConversionDome] Dome restored after clutch save");
        }

        public void ExpandToFullMap(float mapWidth, float mapHeight)
        {
            float diagonal = Mathf.Sqrt(mapWidth * mapWidth + mapHeight * mapHeight);
            SetRadius(diagonal);
        }

        private void SetRadius(float radius)
        {
            CurrentRadius = Mathf.Max(0f, radius);
            RebuildDisc(); // Disc needs full rebuild for terrain conformance
            UpdateShieldScale();
        }

        private void UpdateShieldScale()
        {
            if (_shieldSphere == null) return;
            _shieldSphere.Scale = Vector3.One * Mathf.Max(0.01f, CurrentRadius);
            _shieldSphere.Position = new Vector3(0, CurrentRadius * 0.3f, 0);
        }

        // ── Last stand ──

        private void EnterLastStand()
        {
            IsLastStand = true;
            _lastStandHits = LAST_STAND_MAX_HITS;
            SetRadius(0.5f);
            GD.Print("[ConversionDome] DOME COLLAPSED — Last Stand!");
            GameEvents.OnDomeCollapsed?.Invoke();
        }

        public bool TakeLastStandHit()
        {
            if (!IsLastStand) return true;
            _lastStandHits--;
            FlashShield();
            if (_lastStandHits <= 0)
            {
                GD.Print("[ConversionDome] Last Stand depleted — game over");
                return false;
            }
            GD.Print($"[ConversionDome] Last Stand: {_lastStandHits}/{LAST_STAND_MAX_HITS} hits remaining");
            return true;
        }

        public int LastStandHitsRemaining => _lastStandHits;

        // ── Hit flash ──

        private void OnHarvesterDamaged(float currentHP)
        {
            FlashShield();
        }

        public void FlashShield()
        {
            _shieldSphere.Visible = true;
            _shieldFlashTimer = 0.5f;
            _shieldMat.AlbedoColor = new Color(0.3f, 0.8f, 1.0f, 0.25f);
            _shieldMat.EmissionEnergyMultiplier = 2f;
        }

        // ── Queries ──

        public bool IsInsideDome(Vector3 worldPos)
        {
            float dist = new Vector2(worldPos.X - GlobalPosition.X, worldPos.Z - GlobalPosition.Z).Length();
            return dist <= CurrentRadius;
        }

        // ── Cleanup ──

        public override void _ExitTree()
        {
            GameEvents.OnHarvesterDamaged -= OnHarvesterDamaged;
            foreach (var p in _particles)
            {
                if (GodotObject.IsInstanceValid(p.Mesh))
                    p.Mesh.QueueFree();
            }
            _particles.Clear();
        }
    }
}
